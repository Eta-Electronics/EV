################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../F28003x_lnk.cmd 

SYSCFG_SRCS += \
../EV_VA.syscfg 

CLA_SRCS += \
../EV_VA_cla.cla 

LIB_SRCS += \
C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib/ccs/Debug/driverlib.lib 

ASM_SRCS += \
../CLAln.asm \
../CLAlnTable.asm 

C_SRCS += \
../EV_VA.c \
./syscfg/board.c \
./syscfg/c2000ware_libraries.c \
../EV_VA_main.c 

GEN_FILES += \
./syscfg/board.c \
./syscfg/board.opt \
./syscfg/c2000ware_libraries.opt \
./syscfg/c2000ware_libraries.c 

CLA_DEPS += \
./EV_VA_cla.d 

GEN_MISC_DIRS += \
./syscfg 

C_DEPS += \
./EV_VA.d \
./syscfg/board.d \
./syscfg/c2000ware_libraries.d \
./EV_VA_main.d 

GEN_OPTS += \
./syscfg/board.opt \
./syscfg/c2000ware_libraries.opt 

OBJS += \
./CLAln.obj \
./CLAlnTable.obj \
./EV_VA.obj \
./syscfg/board.obj \
./syscfg/c2000ware_libraries.obj \
./EV_VA_cla.obj \
./EV_VA_main.obj 

ASM_DEPS += \
./CLAln.d \
./CLAlnTable.d 

GEN_MISC_FILES += \
./syscfg/board.h \
./syscfg/board.cmd.genlibs \
./syscfg/pinmux.csv \
./syscfg/epwm.dot \
./syscfg/adc.dot \
./syscfg/c2000ware_libraries.cmd.genlibs \
./syscfg/c2000ware_libraries.h \
./syscfg/clocktree.h 

GEN_MISC_DIRS__QUOTED += \
"syscfg" 

OBJS__QUOTED += \
"CLAln.obj" \
"CLAlnTable.obj" \
"EV_VA.obj" \
"syscfg\board.obj" \
"syscfg\c2000ware_libraries.obj" \
"EV_VA_cla.obj" \
"EV_VA_main.obj" 

GEN_MISC_FILES__QUOTED += \
"syscfg\board.h" \
"syscfg\board.cmd.genlibs" \
"syscfg\pinmux.csv" \
"syscfg\epwm.dot" \
"syscfg\adc.dot" \
"syscfg\c2000ware_libraries.cmd.genlibs" \
"syscfg\c2000ware_libraries.h" \
"syscfg\clocktree.h" 

C_DEPS__QUOTED += \
"EV_VA.d" \
"syscfg\board.d" \
"syscfg\c2000ware_libraries.d" \
"EV_VA_main.d" 

GEN_FILES__QUOTED += \
"syscfg\board.c" \
"syscfg\board.opt" \
"syscfg\c2000ware_libraries.opt" \
"syscfg\c2000ware_libraries.c" 

CLA_DEPS__QUOTED += \
"EV_VA_cla.d" 

ASM_DEPS__QUOTED += \
"CLAln.d" \
"CLAlnTable.d" 

ASM_SRCS__QUOTED += \
"../CLAln.asm" \
"../CLAlnTable.asm" 

C_SRCS__QUOTED += \
"../EV_VA.c" \
"./syscfg/board.c" \
"./syscfg/c2000ware_libraries.c" \
"../EV_VA_main.c" 

SYSCFG_SRCS__QUOTED += \
"../EV_VA.syscfg" 


