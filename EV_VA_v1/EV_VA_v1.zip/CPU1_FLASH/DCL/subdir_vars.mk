################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
ASM_SRCS += \
../DCL/DCL_DF13_C1.asm \
../DCL/DCL_DF13_C2C3.asm \
../DCL/DCL_DF22_C1.asm \
../DCL/DCL_DF22_C2C3.asm \
../DCL/DCL_DF22_L1.asm \
../DCL/DCL_DF22_L2L3.asm \
../DCL/DCL_DF23_C1.asm \
../DCL/DCL_DF23_C2C3.asm \
../DCL/DCL_DF23_L1.asm \
../DCL/DCL_DF23_L2L3.asm \
../DCL/DCL_clamp_C1.asm \
../DCL/DCL_clamp_L1.asm 

OBJS += \
./DCL/DCL_DF13_C1.obj \
./DCL/DCL_DF13_C2C3.obj \
./DCL/DCL_DF22_C1.obj \
./DCL/DCL_DF22_C2C3.obj \
./DCL/DCL_DF22_L1.obj \
./DCL/DCL_DF22_L2L3.obj \
./DCL/DCL_DF23_C1.obj \
./DCL/DCL_DF23_C2C3.obj \
./DCL/DCL_DF23_L1.obj \
./DCL/DCL_DF23_L2L3.obj \
./DCL/DCL_clamp_C1.obj \
./DCL/DCL_clamp_L1.obj 

ASM_DEPS += \
./DCL/DCL_DF13_C1.d \
./DCL/DCL_DF13_C2C3.d \
./DCL/DCL_DF22_C1.d \
./DCL/DCL_DF22_C2C3.d \
./DCL/DCL_DF22_L1.d \
./DCL/DCL_DF22_L2L3.d \
./DCL/DCL_DF23_C1.d \
./DCL/DCL_DF23_C2C3.d \
./DCL/DCL_DF23_L1.d \
./DCL/DCL_DF23_L2L3.d \
./DCL/DCL_clamp_C1.d \
./DCL/DCL_clamp_L1.d 

OBJS__QUOTED += \
"DCL\DCL_DF13_C1.obj" \
"DCL\DCL_DF13_C2C3.obj" \
"DCL\DCL_DF22_C1.obj" \
"DCL\DCL_DF22_C2C3.obj" \
"DCL\DCL_DF22_L1.obj" \
"DCL\DCL_DF22_L2L3.obj" \
"DCL\DCL_DF23_C1.obj" \
"DCL\DCL_DF23_C2C3.obj" \
"DCL\DCL_DF23_L1.obj" \
"DCL\DCL_DF23_L2L3.obj" \
"DCL\DCL_clamp_C1.obj" \
"DCL\DCL_clamp_L1.obj" 

ASM_DEPS__QUOTED += \
"DCL\DCL_DF13_C1.d" \
"DCL\DCL_DF13_C2C3.d" \
"DCL\DCL_DF22_C1.d" \
"DCL\DCL_DF22_C2C3.d" \
"DCL\DCL_DF22_L1.d" \
"DCL\DCL_DF22_L2L3.d" \
"DCL\DCL_DF23_C1.d" \
"DCL\DCL_DF23_C2C3.d" \
"DCL\DCL_DF23_L1.d" \
"DCL\DCL_DF23_L2L3.d" \
"DCL\DCL_clamp_C1.d" \
"DCL\DCL_clamp_L1.d" 

ASM_SRCS__QUOTED += \
"../DCL/DCL_DF13_C1.asm" \
"../DCL/DCL_DF13_C2C3.asm" \
"../DCL/DCL_DF22_C1.asm" \
"../DCL/DCL_DF22_C2C3.asm" \
"../DCL/DCL_DF22_L1.asm" \
"../DCL/DCL_DF22_L2L3.asm" \
"../DCL/DCL_DF23_C1.asm" \
"../DCL/DCL_DF23_C2C3.asm" \
"../DCL/DCL_DF23_L1.asm" \
"../DCL/DCL_DF23_L2L3.asm" \
"../DCL/DCL_clamp_C1.asm" \
"../DCL/DCL_clamp_L1.asm" 


