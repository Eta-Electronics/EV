/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************

//
// ANALOG -> ANALOGPinMux0 Pinmux
//

//
// EPWM3 -> EV_PWM_B_main Pinmux
//
//
// EPWM3_A - GPIO Settings
//
#define GPIO_PIN_EPWM3_A 14
#define EV_PWM_B_main_EPWMA_GPIO 14
#define EV_PWM_B_main_EPWMA_PIN_CONFIG GPIO_14_EPWM3_A
//
// EPWM3_B - GPIO Settings
//
#define GPIO_PIN_EPWM3_B 15
#define EV_PWM_B_main_EPWMB_GPIO 15
#define EV_PWM_B_main_EPWMB_PIN_CONFIG GPIO_15_EPWM3_B

//
// EPWM4 -> EV_PWM_B_snb Pinmux
//
//
// EPWM4_A - GPIO Settings
//
#define GPIO_PIN_EPWM4_A 22
#define EV_PWM_B_snb_EPWMA_GPIO 22
#define EV_PWM_B_snb_EPWMA_PIN_CONFIG GPIO_22_EPWM4_A
//
// EPWM4_B - GPIO Settings
//
#define GPIO_PIN_EPWM4_B 7
#define EV_PWM_B_snb_EPWMB_GPIO 7
#define EV_PWM_B_snb_EPWMB_PIN_CONFIG GPIO_7_EPWM4_B
//
// GPIO34 - GPIO Settings
//
#define EV_GD_EN_seed_GPIO_PIN_CONFIG GPIO_34_GPIO34
//
// GPIO50 - GPIO Settings
//
#define EV_LED1_GPIO_PIN_CONFIG GPIO_50_GPIO50
//
// GPIO51 - GPIO Settings
//
#define EV_LED2_GPIO_PIN_CONFIG GPIO_51_GPIO51
//
// GPIO52 - GPIO Settings
//
#define EV_LED3_GPIO_PIN_CONFIG GPIO_52_GPIO52
//
// GPIO10 - GPIO Settings
//
#define TEST1_GPIO_PIN_CONFIG GPIO_10_GPIO10

//*****************************************************************************
//
// ADC Configurations
//
//*****************************************************************************
#define EV_ADCA_BASE ADCA_BASE
#define EV_ADCA_RESULT_BASE ADCARESULT_BASE
#define EV_ADCA_EV_IL1_sen ADC_SOC_NUMBER0
#define EV_ADCA_FORCE_EV_IL1_sen ADC_FORCE_SOC0
#define EV_ADCA_SAMPLE_WINDOW_EV_IL1_sen 100
#define EV_ADCA_TRIGGER_SOURCE_EV_IL1_sen ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_IL1_sen ADC_CH_ADCIN5
#define EV_ADCA_EV_IL2_sen ADC_SOC_NUMBER1
#define EV_ADCA_FORCE_EV_IL2_sen ADC_FORCE_SOC1
#define EV_ADCA_SAMPLE_WINDOW_EV_IL2_sen 100
#define EV_ADCA_TRIGGER_SOURCE_EV_IL2_sen ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_IL2_sen ADC_CH_ADCIN7
#define EV_ADCA_EV_Io_sen ADC_SOC_NUMBER2
#define EV_ADCA_FORCE_EV_Io_sen ADC_FORCE_SOC2
#define EV_ADCA_SAMPLE_WINDOW_EV_Io_sen 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Io_sen ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Io_sen ADC_CH_ADCIN12
#define EV_ADCA_EV_Vo_sen ADC_SOC_NUMBER3
#define EV_ADCA_FORCE_EV_Vo_sen ADC_FORCE_SOC3
#define EV_ADCA_SAMPLE_WINDOW_EV_Vo_sen 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Vo_sen ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Vo_sen ADC_CH_ADCIN14
#define EV_ADCA_EV_Va_sen ADC_SOC_NUMBER4
#define EV_ADCA_FORCE_EV_Va_sen ADC_FORCE_SOC4
#define EV_ADCA_SAMPLE_WINDOW_EV_Va_sen 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Va_sen ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Va_sen ADC_CH_ADCIN2
#define EV_ADCA_EV_Vb_sen ADC_SOC_NUMBER5
#define EV_ADCA_FORCE_EV_Vb_sen ADC_FORCE_SOC5
#define EV_ADCA_SAMPLE_WINDOW_EV_Vb_sen 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Vb_sen ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Vb_sen ADC_CH_ADCIN6
#define EV_ADCA_EV_Temp_Q1 ADC_SOC_NUMBER6
#define EV_ADCA_FORCE_EV_Temp_Q1 ADC_FORCE_SOC6
#define EV_ADCA_SAMPLE_WINDOW_EV_Temp_Q1 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Temp_Q1 ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Temp_Q1 ADC_CH_ADCIN8
#define EV_ADCA_EV_Temp_Q2 ADC_SOC_NUMBER7
#define EV_ADCA_FORCE_EV_Temp_Q2 ADC_FORCE_SOC7
#define EV_ADCA_SAMPLE_WINDOW_EV_Temp_Q2 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Temp_Q2 ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Temp_Q2 ADC_CH_ADCIN4
#define EV_ADCA_EV_Temp_Qs1 ADC_SOC_NUMBER8
#define EV_ADCA_FORCE_EV_Temp_Qs1 ADC_FORCE_SOC8
#define EV_ADCA_SAMPLE_WINDOW_EV_Temp_Qs1 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Temp_Qs1 ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Temp_Qs1 ADC_CH_ADCIN10
#define EV_ADCA_EV_Temp_Qs2 ADC_SOC_NUMBER9
#define EV_ADCA_FORCE_EV_Temp_Qs2 ADC_FORCE_SOC9
#define EV_ADCA_SAMPLE_WINDOW_EV_Temp_Qs2 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Temp_Qs2 ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Temp_Qs2 ADC_CH_ADCIN9
#define EV_ADCA_EV_Temp_L ADC_SOC_NUMBER10
#define EV_ADCA_FORCE_EV_Temp_L ADC_FORCE_SOC10
#define EV_ADCA_SAMPLE_WINDOW_EV_Temp_L 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Temp_L ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Temp_L ADC_CH_ADCIN11
#define EV_ADCA_EV_Temp_BDG_D ADC_SOC_NUMBER11
#define EV_ADCA_FORCE_EV_Temp_BDG_D ADC_FORCE_SOC11
#define EV_ADCA_SAMPLE_WINDOW_EV_Temp_BDG_D 100
#define EV_ADCA_TRIGGER_SOURCE_EV_Temp_BDG_D ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCA_CHANNEL_EV_Temp_BDG_D ADC_CH_ADCIN3
void EV_ADCA_init();

#define EV_ADCB_BASE ADCB_BASE
#define EV_ADCB_RESULT_BASE ADCBRESULT_BASE
#define EV_ADCB_EV_DACA_check ADC_SOC_NUMBER0
#define EV_ADCB_FORCE_EV_DACA_check ADC_FORCE_SOC0
#define EV_ADCB_SAMPLE_WINDOW_EV_DACA_check 100
#define EV_ADCB_TRIGGER_SOURCE_EV_DACA_check ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCB_CHANNEL_EV_DACA_check ADC_CH_ADCIN0
#define EV_ADCB_EV_DACB_check ADC_SOC_NUMBER1
#define EV_ADCB_FORCE_EV_DACB_check ADC_FORCE_SOC1
#define EV_ADCB_SAMPLE_WINDOW_EV_DACB_check 100
#define EV_ADCB_TRIGGER_SOURCE_EV_DACB_check ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCB_CHANNEL_EV_DACB_check ADC_CH_ADCIN2
void EV_ADCB_init();

#define EV_ADCC_BASE ADCC_BASE
#define EV_ADCC_RESULT_BASE ADCCRESULT_BASE
#define EV_ADCC_EV_DSP_Temp ADC_SOC_NUMBER0
#define EV_ADCC_FORCE_EV_DSP_Temp ADC_FORCE_SOC0
#define EV_ADCC_SAMPLE_WINDOW_EV_DSP_Temp 700
#define EV_ADCC_TRIGGER_SOURCE_EV_DSP_Temp ADC_TRIGGER_EPWM3_SOCA
#define EV_ADCC_CHANNEL_EV_DSP_Temp ADC_CH_ADCIN12
void EV_ADCC_init();


//*****************************************************************************
//
// ASYSCTL Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// CLA Configurations
//
//*****************************************************************************
#define EV_CTRL_CLA_BASE CLA1_BASE

//
// The following are symbols defined in the CLA assembly code
// Including them in the shared header file makes them global
// and the main CPU can make use of them.
//
__attribute__((interrupt)) void Cla1Task1();
void EV_CTRL_CLA_init();


//*****************************************************************************
//
// DAC Configurations
//
//*****************************************************************************
#define EV_DACA_BASE DACA_BASE
void EV_DACA_init();
#define EV_DACB_BASE DACB_BASE
void EV_DACB_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define EV_PWM_B_main_BASE EPWM3_BASE
#define EV_PWM_B_main_TBPRD 1411
#define EV_PWM_B_main_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define EV_PWM_B_main_TBPHS 0
#define EV_PWM_B_main_CMPA 0
#define EV_PWM_B_main_CMPB 0
#define EV_PWM_B_main_CMPC 0
#define EV_PWM_B_main_CMPD 0
#define EV_PWM_B_main_DBRED 0
#define EV_PWM_B_main_DBFED 0
#define EV_PWM_B_main_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EV_PWM_B_main_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EV_PWM_B_main_INTERRUPT_SOURCE EPWM_INT_TBCTR_ZERO
#define EV_PWM_B_snb_BASE EPWM4_BASE
#define EV_PWM_B_snb_TBPRD 1411
#define EV_PWM_B_snb_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define EV_PWM_B_snb_TBPHS 0
#define EV_PWM_B_snb_CMPA 0
#define EV_PWM_B_snb_CMPB 0
#define EV_PWM_B_snb_CMPC 0
#define EV_PWM_B_snb_CMPD 0
#define EV_PWM_B_snb_DBRED 0
#define EV_PWM_B_snb_DBFED 0
#define EV_PWM_B_snb_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EV_PWM_B_snb_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EV_PWM_B_snb_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define EV_GD_EN_seed 34
void EV_GD_EN_seed_init();
#define EV_LED1 50
void EV_LED1_init();
#define EV_LED2 51
void EV_LED2_init();
#define EV_LED3 52
void EV_LED3_init();
#define TEST1 10
void TEST1_init();

//*****************************************************************************
//
// INTERRUPT Configurations
//
//*****************************************************************************

// Interrupt Settings for INT_EV_CTRL_CLA1
#define INT_EV_CTRL_CLA1 INT_CLA1_1
#define INT_EV_CTRL_CLA1_INTERRUPT_ACK_GROUP INTERRUPT_ACK_GROUP11
extern __interrupt void INT_EV_CTRL_CLA1_ISR(void);

//*****************************************************************************
//
// MEMCFG Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ADC_init();
void	ASYSCTL_init();
void	CLA_init();
void	DAC_init();
void	EPWM_init();
void	GPIO_init();
void	INTERRUPT_init();
void	MEMCFG_init();
void	SYNC_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
