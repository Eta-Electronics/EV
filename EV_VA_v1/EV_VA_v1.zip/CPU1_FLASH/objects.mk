################################################################################
# Automatically-generated file. Do not edit!
################################################################################

USER_OBJS :=

LIBS := -l"C:/ti/c2000/C2000Ware_5_00_00_00/libraries/boot_rom/f28003x/rev0/rom_symbol_libs/CLADATAROMSymbols/F28003x_CLADATROM_Symbols.lib" -lc2000ware_libraries.cmd.genlibs -llibc.a

