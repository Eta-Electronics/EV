################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
%.obj: ../%.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O4 --opt_for_speed=5 --fp_mode=relaxed --include_path="C:/github/EV/EV_VA_v1" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00" --include_path="C:/github/EV/EV_VA_v1/device" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib" --include_path="C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/github/EV" --advice:performance=all --define=CLA_MATH_TABLES_IN_ROM=1 --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --cla_background_task=off --cla_signed_compare_workaround=on --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" --include_path="C:/github/EV/EV_VA_v1/CPU1_FLASH/syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.obj: ../%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O4 --opt_for_speed=5 --fp_mode=relaxed --include_path="C:/github/EV/EV_VA_v1" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00" --include_path="C:/github/EV/EV_VA_v1/device" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib" --include_path="C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/github/EV" --advice:performance=all --define=CLA_MATH_TABLES_IN_ROM=1 --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --cla_background_task=off --cla_signed_compare_workaround=on --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" --include_path="C:/github/EV/EV_VA_v1/CPU1_FLASH/syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

build-1784486305: ../EV_VA.syscfg
	@echo 'Building file: "$<"'
	@echo 'Invoking: SysConfig'
	"C:/ti/ccs1240/ccs/utils/sysconfig_1.19.0/sysconfig_cli.bat" --script "C:/github/EV/EV_VA_v1/EV_VA.syscfg" -o "syscfg" -s "C:/ti/c2000/C2000Ware_5_00_00_00/.metadata/sdk.json" -d "F28003x" --package 100PZ --part F28003x_100PZ --compiler ccs
	@echo 'Finished building: "$<"'
	@echo ' '

syscfg/board.c: build-1784486305 ../EV_VA.syscfg
syscfg/board.h: build-1784486305
syscfg/board.cmd.genlibs: build-1784486305
syscfg/board.opt: build-1784486305
syscfg/pinmux.csv: build-1784486305
syscfg/epwm.dot: build-1784486305
syscfg/adc.dot: build-1784486305
syscfg/c2000ware_libraries.cmd.genlibs: build-1784486305
syscfg/c2000ware_libraries.opt: build-1784486305
syscfg/c2000ware_libraries.c: build-1784486305
syscfg/c2000ware_libraries.h: build-1784486305
syscfg/clocktree.h: build-1784486305
syscfg: build-1784486305

syscfg/%.obj: ./syscfg/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O4 --opt_for_speed=5 --fp_mode=relaxed --include_path="C:/github/EV/EV_VA_v1" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00" --include_path="C:/github/EV/EV_VA_v1/device" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib" --include_path="C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/github/EV" --advice:performance=all --define=CLA_MATH_TABLES_IN_ROM=1 --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --cla_background_task=off --cla_signed_compare_workaround=on --preproc_with_compile --preproc_dependency="syscfg/$(basename $(<F)).d_raw" --include_path="C:/github/EV/EV_VA_v1/CPU1_FLASH/syscfg" --obj_directory="syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

%.obj: ../%.cla $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O4 --opt_for_speed=5 --fp_mode=relaxed --include_path="C:/github/EV/EV_VA_v1" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00" --include_path="C:/github/EV/EV_VA_v1/device" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib" --include_path="C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/github/EV" --advice:performance=all --define=CLA_MATH_TABLES_IN_ROM=1 --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --cla_background_task=off --cla_signed_compare_workaround=on --preproc_with_compile --preproc_dependency="$(basename $(<F)).d_raw" --include_path="C:/github/EV/EV_VA_v1/CPU1_FLASH/syscfg" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


