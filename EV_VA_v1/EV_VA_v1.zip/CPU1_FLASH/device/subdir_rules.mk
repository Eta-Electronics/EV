################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Each subdirectory must supply rules for building sources it contributes
device/%.obj: ../device/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O4 --opt_for_speed=5 --fp_mode=relaxed --include_path="C:/github/EV/EV_VA_v1" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00" --include_path="C:/github/EV/EV_VA_v1/device" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib" --include_path="C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/github/EV" --advice:performance=all --define=CLA_MATH_TABLES_IN_ROM=1 --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --cla_background_task=off --cla_signed_compare_workaround=on --preproc_with_compile --preproc_dependency="device/$(basename $(<F)).d_raw" --include_path="C:/github/EV/EV_VA_v1/CPU1_FLASH/syscfg" --obj_directory="device" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '

device/%.obj: ../device/%.asm $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'Building file: "$<"'
	@echo 'Invoking: C2000 Compiler'
	"C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/bin/cl2000" -v28 -ml -mt --cla_support=cla2 --float_support=fpu32 --tmu_support=tmu0 --vcu_support=vcrc -O4 --opt_for_speed=5 --fp_mode=relaxed --include_path="C:/github/EV/EV_VA_v1" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00" --include_path="C:/github/EV/EV_VA_v1/device" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/driverlib/f28003x/driverlib" --include_path="C:/ti/ccs1240/ccs/tools/compiler/ti-cgt-c2000_22.6.1.LTS/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/math/CLAmath/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/source" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/ti/c2000/C2000Ware_5_00_00_00/libraries/control/DCL/c28/include" --include_path="C:/github/EV" --advice:performance=all --define=CLA_MATH_TABLES_IN_ROM=1 --define=_FLASH --diag_suppress=10063 --diag_warning=225 --diag_wrap=off --display_error_number --gen_func_subsections=on --abi=eabi --cla_background_task=off --cla_signed_compare_workaround=on --preproc_with_compile --preproc_dependency="device/$(basename $(<F)).d_raw" --include_path="C:/github/EV/EV_VA_v1/CPU1_FLASH/syscfg" --obj_directory="device" $(GEN_OPTS__FLAG) "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


