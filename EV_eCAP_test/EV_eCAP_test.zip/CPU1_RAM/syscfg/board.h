/*
 * Copyright (c) 2020 Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#ifndef BOARD_H
#define BOARD_H

//*****************************************************************************
//
// If building with a C++ compiler, make all of the definitions in this header
// have a C binding.
//
//*****************************************************************************
#ifdef __cplusplus
extern "C"
{
#endif

//
// Included Files
//

#include "driverlib.h"
#include "device.h"

//*****************************************************************************
//
// PinMux Configurations
//
//*****************************************************************************

//
// EPWM1 -> EPWM1_TEST Pinmux
//
//
// EPWM1_A - GPIO Settings
//
#define GPIO_PIN_EPWM1_A 0
#define EPWM1_TEST_EPWMA_GPIO 0
#define EPWM1_TEST_EPWMA_PIN_CONFIG GPIO_0_EPWM1_A
//
// EPWM1_B - GPIO Settings
//
#define GPIO_PIN_EPWM1_B 1
#define EPWM1_TEST_EPWMB_GPIO 1
#define EPWM1_TEST_EPWMB_PIN_CONFIG GPIO_1_EPWM1_B

//
// EPWM2 -> EPWM2_TEST Pinmux
//
//
// EPWM2_A - GPIO Settings
//
#define GPIO_PIN_EPWM2_A 2
#define EPWM2_TEST_EPWMA_GPIO 2
#define EPWM2_TEST_EPWMA_PIN_CONFIG GPIO_2_EPWM2_A
//
// EPWM2_B - GPIO Settings
//
#define GPIO_PIN_EPWM2_B 3
#define EPWM2_TEST_EPWMB_GPIO 3
#define EPWM2_TEST_EPWMB_PIN_CONFIG GPIO_3_EPWM2_B
//
// GPIO16 - GPIO Settings
//
#define GPIO_TEST1_GPIO_PIN_CONFIG GPIO_16_GPIO16

//*****************************************************************************
//
// ECAP Configurations
//
//*****************************************************************************
#define ECAP1_TEST_BASE ECAP1_BASE
#define ECAP1_TEST_SIGNAL_MUNIT_BASE ECAP1SIGNALMONITORING_BASE
void ECAP1_TEST_init();

//*****************************************************************************
//
// EPWM Configurations
//
//*****************************************************************************
#define EPWM1_TEST_BASE EPWM1_BASE
#define EPWM1_TEST_TBPRD 1411
#define EPWM1_TEST_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define EPWM1_TEST_TBPHS 0
#define EPWM1_TEST_CMPA 141
#define EPWM1_TEST_CMPB 0
#define EPWM1_TEST_CMPC 0
#define EPWM1_TEST_CMPD 0
#define EPWM1_TEST_DBRED 0
#define EPWM1_TEST_DBFED 0
#define EPWM1_TEST_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM1_TEST_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM1_TEST_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED
#define EPWM2_TEST_BASE EPWM2_BASE
#define EPWM2_TEST_TBPRD 1000
#define EPWM2_TEST_COUNTER_MODE EPWM_COUNTER_MODE_UP
#define EPWM2_TEST_TBPHS 0
#define EPWM2_TEST_CMPA 847
#define EPWM2_TEST_CMPB 0
#define EPWM2_TEST_CMPC 0
#define EPWM2_TEST_CMPD 0
#define EPWM2_TEST_DBRED 0
#define EPWM2_TEST_DBFED 0
#define EPWM2_TEST_TZA_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM2_TEST_TZB_ACTION EPWM_TZ_ACTION_HIGH_Z
#define EPWM2_TEST_INTERRUPT_SOURCE EPWM_INT_TBCTR_DISABLED

//*****************************************************************************
//
// GPIO Configurations
//
//*****************************************************************************
#define GPIO_TEST1 16
void GPIO_TEST1_init();

//*****************************************************************************
//
// INPUTXBAR Configurations
//
//*****************************************************************************
#define myINPUTXBARINPUT0_SOURCE 16
#define myINPUTXBARINPUT0_INPUT XBAR_INPUT7
void myINPUTXBARINPUT0_init();

//*****************************************************************************
//
// SYNC Scheme Configurations
//
//*****************************************************************************

//*****************************************************************************
//
// Board Configurations
//
//*****************************************************************************
void	Board_init();
void	ECAP_init();
void	EPWM_init();
void	GPIO_init();
void	INPUTXBAR_init();
void	SYNC_init();
void	PinMux_init();

//*****************************************************************************
//
// Mark the end of the C bindings section for C++ compilers.
//
//*****************************************************************************
#ifdef __cplusplus
}
#endif

#endif  // end of BOARD_H definition
